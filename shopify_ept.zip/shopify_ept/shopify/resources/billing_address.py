from ..base import ShopifyResource


class BillingAddress(ShopifyResource):
    pass
