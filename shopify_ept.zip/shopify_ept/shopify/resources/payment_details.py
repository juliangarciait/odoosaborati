from ..base import ShopifyResource


class PaymentDetails(ShopifyResource):
    pass
