from ..base import ShopifyResource


class Report(ShopifyResource):
    pass
