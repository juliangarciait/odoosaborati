from ..base import ShopifyResource


class Rule(ShopifyResource):
    pass
